========================================
  PASTA TEXTUR - ASSETS DOS PLUGINS
========================================

Esta pasta contém os assets (texturas, modelos, etc.) dos plugins,
organizados fora da pasta server para fácil acesso e backup.

ESTRUTURA:
---------
textur/
  ExecutableItems/
    assets/          - Resource pack do ExecutableItems (ei, elypack, exemple)
  Nexo/
    pack/            - Pack do Nexo (external_packs, pack.zip)
      external_packs/
        minecraft-hats-mini-pack-2/ - Chapéus Pack 2 (capa, lã, cogumelo)
        minecraft-hats-mini-pack-3.zip - Chapéus Pack 3

Os plugins continuam funcionando normalmente - os arquivos originais
permanecem em server/plugins/. Esta é uma cópia para organização.

========================================
