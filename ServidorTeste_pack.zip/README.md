# Resource Pack - Servidor Minecraft

Pack completo com BetterModel e Key Staff.

## Como usar no GitHub

1. **Zipe esta pasta** (o conteúdo: `assets/` e `pack.mcmeta`)
2. Envie o zip para o repositório (ex: substitua `ServidorTeste.zip`)
3. URL do pack: `https://cdn.jsdelivr.net/gh/ahr7onix/resource-pack@main/NOME_DO_ARQUIVO.zip`

## Key Staff

Para dar a arma a um jogador:
```
/give @p stick[item_model={value:"bettermodel:items/bm_models"},custom_model_data=25]
```
